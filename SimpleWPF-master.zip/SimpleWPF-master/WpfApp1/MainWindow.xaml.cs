﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;
using System.Text.RegularExpressions;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Name = "MainWindow";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void openWindowButton_Click(object sender, RoutedEventArgs e)
        {
            SecondWindow window = new SecondWindow();
            window.Show();
            this.Hide();
        }

        private void press0Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 0;
        }

        private void press1Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 1;
        }

        private void press2Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 2;
        }

        private void press3Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 3;
        }

        private void press4Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 4;
        }

        private void press5Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 5;
        }

        private void press6Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 6;
        }

        private void press7Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 7;
        }

        private void press8Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 8;
        }

        private void press9Button_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += 9;
        }

        private void pressPLUSButton_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += '+';
        }

        private void pressMINUSButton_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += '-';
        }

        private void pressUMNOZHITButton_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += '*';
        }

        private void pressDELITButton_Click(object sender, RoutedEventArgs e)
        {
            inputTextBlock.Text += '/';
        }

        private void pressRAVNOButton_Click(object sender, RoutedEventArgs e)
        {
            string ex = inputTextBlock.Text;
            inputTextBlock.Text = Calculator(ex).ToString();
        }

        private double Calculator(string ex)
        {
            Regex regex = new Regex(@"([\d]+[*/+-])+[\d]+");
            Match result = regex.Match(ex);
            if (result != null)
            {
                int operation1 = Int32.Parse(result.Groups[1].Value);
                int operation2 = Int32.Parse((result.Groups[3].Value));
                string operation = result.Groups[2].Value;

                switch(operation)
                {
                    case "/"
                }

            }
            return 0;
        }
    }
}
